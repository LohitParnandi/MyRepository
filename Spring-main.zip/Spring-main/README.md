copy first Employee and after that EmployeeController
